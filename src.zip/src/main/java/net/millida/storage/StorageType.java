package net.millida.storage;

import lombok.Getter;

@Getter
public enum StorageType {

    MYSQL,
    YML

}
